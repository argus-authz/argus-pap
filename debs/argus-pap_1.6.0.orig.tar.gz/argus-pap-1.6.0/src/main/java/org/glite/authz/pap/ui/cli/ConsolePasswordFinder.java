/**
 * Copyright (c) Members of the EGEE Collaboration. 2006-2009.
 * See http://www.eu-egee.org/partners/ for details on the copyright holders.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.glite.authz.pap.ui.cli;

import java.io.Console;

import org.bouncycastle.openssl.PasswordFinder;

public class ConsolePasswordFinder implements PasswordFinder{

	private final String promptMessage;
	
	private String lastReadPassword = null;
	
	public ConsolePasswordFinder(String prompt) {
		promptMessage = prompt;
	}
	
	public char[] getPassword() {
		Console console = System.console();
		
		if (console == null)
			throw new IllegalStateException("Error reading password from console: no console found for this JVM!");
		
		char[] pwd = console.readPassword(promptMessage);
		
		if (pwd != null)
			lastReadPassword = new String(pwd);
		
		return pwd;
	}

	/**
	 * @return the lastReadPassword
	 */
	public synchronized String getLastReadPassword() {
		return lastReadPassword;
	}
	
}
